# AI 执行检查点

本文件是后续实现进度记录，不能替代长期契约。

## 初始状态

- Review baseline：`f945ef153eb3344abd3801a3c2e4002fd25d80be`
- 本轮工作：评审、合成探针、截图、任务包、中英文提示词。
- 产品实现改动：无。
- 任务状态：A01–A20 全部 TODO。报告完成不等于任务修复。
- 当前下一项：**A01 — 冻结真实边界并修正 ID**。
- 第一条具体操作：查看当前 git status/commit，读适用 AGENTS/ADR，然后枚举 applicationStore 所有发出命令与 Rust DTO 的身份约束，建立 frontend→Rust 失败 fixture。
- 注意：evidence 中的 probes 断言的是 bug 现状，不能原样当作修复后的通过标准。

| ID | 状态 | 依赖/交接提示 |
|---|---|---|
| A01 | TODO | 先修合法 ID 与真实 serde 一致性 |
| A02 | TODO | transport 入口、订阅、Tauri bridge |
| A03 | TODO | 清除默认 fixture，真实空状态/搜索 |
| A04 | TODO | 成功与失败诚实，按 turn 路由 |
| A05 | TODO | 正文历史和恢复 |
| A06 | TODO | epoch/重放/缓存 |
| A07 | TODO | ACP 配置与引用 |
| A08 | TODO | 网格和窄窗 |
| A09 | TODO | IME/弹窗/焦点 |
| A10 | TODO | 主题与共享原语 |
| A11 | TODO | zh-CN/en、展示偏好 |
| A12 | TODO | 长正文/工具呈现 |
| A13 | TODO | scope/trust/budget/保留契约 |
| A14 | TODO | 真实记忆与 Context 产品路径 |
| A15 | TODO | 排名、中文、候选界限 |
| A16 | TODO | 性能基准与保语义优化 |
| A17 | TODO | 质量门禁 |
| A18 | TODO | 真实第三方/打包验收；缺环境不得伪装 PASS |
| A19 | TODO | 发布说明、安装/迁移 |
| A20 | TODO | 仅同步设计与安全门槛，不自动上线 |

## 每个切片追加模板

```text
Execution time / environment:
Task ID / subslice:
Baseline / current commit:
Pre-existing unrelated changes:
User-visible outcome:
In scope / out of scope:
Contracts and decisions adopted:
Changed files:
Failure / cancellation / offline / restart:
Security / synchronization impact:
Migration / downgrade:
Regression proof before and after:
Exact verification commands and results:
Screenshots actually inspected:
Not run / blockers / residual risks:
Status (TODO / IN_PROGRESS / DONE-VERIFIED / BLOCKED):
Next task and first concrete action:
```

不要修改本轮评审证据来制造已完成记录。可以在后续条目解释问题已经随哪次实现解决，并链接新的证据。没有用户授权不要自动创建后台任务或循环调度。
